#!/bin/sh

## Enable eth0 to ppp0 nat

# enable ip_forward
echo 1 >/proc/sys/net/ipv4/ip_forward

# Set ip for eth0
ifconfig eth0 192.168.30.1 up

# enable NAT and internet share
iptables -F
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -t nat -A POSTROUTING -o ppp0 -j MASQUERADE


